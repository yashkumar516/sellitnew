<?php include 'header.php' ?>
<?php
 if(isset($_POST['contactquery'])){
     $name = $_POST['name'];
     $mobile = $_POST['mobile'];
     $email = $_POST['email'];
     $messege = $_POST['message'];
     $insertquery = mysqli_query($con,"INSERT INTO `queries` (`name`,`mobile`,`email`,`messege`) VALUES('$name','$mobile','$email','$messege')");
 }
?>
<style>
    .row{
        margin-right: 0px;
    }
</style>
<section class="py-5" style="background-color: #f1f8f8;">
    <div class="container sell">

        <div class="col-lg-12 col-12  mx-auto card">
            <div class="row" id="sell">
                <div class="col-lg-12 col-12">



<form method="post" class="p-3 contact-form">
<div class="form-group">
<input type="text" class="form-control" name="name" placeholder="Your Name" required>
</div>
<div class="form-group">
<input type="email" class="form-control" name="email" placeholder="Your Email" required>
</div>
<div class="form-group">
<input type="text" maxlength="10" class="form-control" name="mobile" placeholder="Phone" required>
</div>
<div class="form-group">
<textarea cols="30" rows="7" class="form-control" name="message"  placeholder="Message" required></textarea>
</div>
<div class="form-group">
<input type="submit" value="Send Message" name="contactquery" class="btn py-2 px-4 text-white" style="background-color:#23699D;" >
</div>
</form>
</div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer1.php' ?>

