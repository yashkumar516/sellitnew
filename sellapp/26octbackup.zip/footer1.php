
    <!-- Optional JavaScript -->
    <div class="container-fluid p-2" id="constantfooter">
  <div class="row">
  <div class="col-4 text-center" ><a href="contact.php" class="text-white"><i class="fas fa-phone-square" style="font-size:30px;"></i></a></div>
  <div class="col-4 text-center" ><a href="index1.php" class="text-white"><i class="fas fa-home" style="font-size:30px;"></i></a></div>
  <div class="col-4 text-center" ><a href="userdashboard.php" class="text-white"><i class="far fa-user-circle" style="font-size:30px;"></i></a></div>
  </div>
</div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<script>
$(document).ready(function(){
 $("#modalsearch").keyup(function(){
   var search = $("#modalsearch").val();
   if(search != ''){
      $.ajax({
				  method: "post",
				  url : "modalfound.php",
				  data:{search:search},
				  dataType: "html",
				  success:function(result)
				  {
            $('#ajaxresponse').fadeIn();
            $("#filter").css("display", "block");
					  $('#ajaxresponse').html(result);
				  }
			});
    }else{
      $('#ajaxresponse').fadeOut();
      $("#filter").css("display", "none");
      $('#ajaxresponse').html("");
    }
 })
});
</script>

<script>
 $(document).ready(function(){
   $("#userpic").on('click',function(){
     $("#prof").toggle();
   });
 });
</script>

