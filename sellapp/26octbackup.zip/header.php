<?php 
 session_start();
 include '../admin/includes/confile.php';
?>
<?php
 if(isset($_SESSION['user'])){
    $user = $_SESSION['user'];
    $usermobile = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `userrecord` WHERE `id` = '$user' "));
    if($usermobile){
      $number = $usermobile ['name'];
    }else{
      $number = '';
    }
 }else{
  $number = '';
 }
?>
<?php
 if(isset($_POST['review']))
  {
    $rname = $_POST['rname'];
    $rcity = $_POST['rcity'];
    $rating = $_POST['rating'];
    $review = $_POST['msg'];
    mysqli_query($con,"INSERT INTO `product_reviews`(`rname`,`rcity`,`rmsg`,`rating`) VALUES('$rname','$rcity','$review','$rating')");
  }
  ?>
  <?php
  if(isset($_POST['newsuser'])){
     $nwsletter = $_POST['newsletter'];
     if( $nwsletter != ''){
        $insertnews = mysqli_query($con,"INSERT INTO `newsletter` (`email`) VALUES('$nwsletter')");
     }
  }

  ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="ScreenOrientation" content="autoRotate:disabled">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/about.css">
    <script src="https://kit.fontawesome.com/695826c815.js" crossorigin="anonymous"></script>

    <title>Sell it</title>
  </head>
  <body>

    <section class="header">
        <div class="container-fluid ">
            <div class="row">
                <div class="col-lg-11 col-xl-10 col-12 mx-auto p-0">
                    <div class="row header-content">
                        <div class="col-lg-3 col-2">
                          <a href="index1.php"><img src="assets/images/footer-logo.png" alt="" class="logo img-fluid"></a> 
                        </div>
                        <div class="col-lg-8 col-10 pr-1 pl-0 search">
                            <input type="text" class="form-control" id="modalsearch" placeholder="Search your Mobile Phone to Sell" name="search">
                              <div class="col-12 col-lg-10" id="filter" >
                                  <div class="row px-2" id="modals">
                                   <ul id="ajaxresponse" type="none">
                              
                                      </ul>
                                  </div>
                            </div>                     
                        </div>
                    </div>
                </div>
             </div>
          </div>
    </section>