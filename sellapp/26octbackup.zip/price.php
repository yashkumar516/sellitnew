<?php include 'header.php' ?>

<section class="sell-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <h1 class="sell-header">Sell Old Samsung Model</h1>
            </div>   
           
        </div>
    </div>
</section>

<section class="product-detail">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-4 ">
                <img src="assets/images/images.jpg" class="img-fluid"  alt="">
                
            </div>
            <div class="col-lg-7 col-7 variant mx-auto">
                <h1 class="sum-heading ">Samsung M31(4GB/64GB)</h1>
                <p class="ques">Get Upto</p>
                <h1 class="sum-heading ">Rs. 10000/-</h1>

                
                <div class="mt-4">
             <a  ><button class="btn contin-btn" >Get Exact Value  <i class="fas fa-arrow-right"></i></button></a> 
                    </div>
            </div>
            </div>
    </div>
</section>


<?php include 'footer1.php' ?>