
<section class="top-selling pt-5">
      <div class="container top-selling-div">
       <div class="row d-flex justify-content-center mb-3 ">
         <div class="col-lg-7 col-12 mx-auto">
           <div class="row">
         <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            <div class="col-lg-4 col-8" id="choosebrand">
            <h1 class="top-sell-heading text-center ">  Top Selling Brands </h1>
            </div>
            <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            </div>
          </div>
          </div>
          <div class="owl-carousel owl-carousel-12  owl-theme ">
          <?php
           $selectquery = mysqli_query($con,"SELECT * FROM `subcategory` WHERE `status` = 'active' AND `top` = 'active' LIMIT 6 ");
           while($artop = mysqli_fetch_assoc( $selectquery ))
           {
          ?>
          <div class="item mb-2">
          <a href="oldmobile.php?id=<?php echo $artop['id'];  ?>"> <img src="../admin/img/<?php echo $artop['subcategory_image'];  ?>" class="box img-fluid" alt=""></a>
          </div>
          <?php
           }
           ?>
        </div>
      </div>
    </section>

    <section class="top-selling pt-5">
      <div class="container top-selling-div">
        <div class="row d-flex justify-content-center mb-3">
         <div class="col-lg-7 col-12 mx-auto">
           <div class="row">
         <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            <div class="col-lg-4 col-8" id="choosebrand">
            <h1 class="top-sell-heading text-center">  Top Selling Models </h1>
            </div>
            <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            </div>
          </div>
          </div>
        <div class="owl-carousel owl-carousel-12  owl-theme py-2">
        <?php
           $selectmodel = mysqli_query($con,"SELECT * FROM `product` WHERE `status` = 'active' AND `best` = 'active' LIMIT 6 ");
           while($armodel = mysqli_fetch_assoc( $selectmodel ))
           {
          ?>
          <div class="item mb-1">
           <a href="variant.php?id=<?php echo $armodel['id'];?>&&bid=<?php echo $armodel['subcategoryid'];?>">
           <div class="text-center" id="md">
           <img src="../admin/img/<?php echo $armodel['product_image'];  ?>" class="img-fluid" alt="">
           <span class="sum-heading text-center"><?php echo $armodel['product_name'];  ?></span>
           </div>
          </a>
        </div>
          <?php
           }
           ?>
        </div>
      </div>
    </section>

    <section class="why-sell">
      <div class="container why-sell-div">
        <div class="col-lg-7 col-12 mx-auto" >
      <div class="row">
         <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            <div class="col-lg-4 col-8" id="choosebrand">
            <h1 class="top-sell-heading text-center pb-4"> Why Sell On SELL IT</h1>
            </div>
            <div class="col-lg-3 col-2">
              <hr style="border: 1px solid #23699D"> 
            </div>
            </div>
          </div>
        <div class="row">
          <div class="col-lg-4 text-center" >
            <div class="row">
            <div class="col-5" >
            <img src="assets/images/safe.png" class="img-fluid" alt="">
            <h1 class="why-sell-heading">  Safe & Secure </h1>
            </div>
            <div class="col-7 pl-0 pt-3">
            <p class="why-sell-detail text-justify">Select your device & we'll help you 
              unlock the best selling price based
              on the present conditions of your 
              gadget & the current market price.
            </p>
            </div>
            </div>
          </div>
          <div class="col-lg-4 text-center" >
          <div class="row">
            <div class="col-5" >
            <img src="assets/images/instant.png" class="img-fluid" alt="">
            <h1 class="why-sell-heading"> Instant Payment </h1>
            </div>
            <div class="col-7 pl-0 pt-3">
            <p class="why-sell-detail text-justify">On accepting the price offered for your device, we'll arrange a free pick up.</p>
          </div>
           </div>
          </div>
          <div class="col-lg-4 text-center" >
          <div class="row">
            <div class="col-5" >
            <img src="assets/images/bestprice.png" class="img-fluid" alt="">
            <h1 class="why-sell-heading"> Best Price </h1>
            </div>
            <div class="col-7 pl-0 pt-3">
            <p class="why-sell-detail text-justify">Instant cash will be handed over to
               you at time of pickupor through
              payment mode of your choice.why-sell-detail text-justify </p>
              </div>
           </div>
          </div>
        </div>

      </div>
    </section>

    <section class="reviewer">
    <div class="container-fluid">
      <div class="col-lg-11 mx-auto px-0">
        <div class="owl-carousel owl-theme">
        <?php
            $fetchreview = mysqli_query($con,"SELECT * FROM `product_reviews` WHERE `status` = 'active'  ");
            while($arrrev = mysqli_fetch_assoc( $fetchreview)){
          ?>
          <div class="item p-4">
                  <div class="row ">
                    <div class="col-lg-2 col-3">
                    <img src="assets/images/face.png" alt="" class="img-fluid" width="39px">
                    </div>
                    <div class="col-lg-6 col-5 pt-3">
                      <h6 class="reviwer-name text-center"><?php echo $arrrev['rname'] ?></h6>
                    </div>
                    <div class="col-4 pt-3 reviewer-rating d-flex justify-content-center">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="far fa-star"></i>
                            </div>
                  </div>
                  <h2 class="reviewer-heading"><?php echo $arrrev['rcity'] ?></h2>
                  <p class=""><?php echo $arrrev['rmsg'] ?></p>
          </div>
          <?php
              }
          ?>
       
        </div>
</div>
</div>
<div class=" mt-3 text-center">
 <button class="btn text-white" style="background-color:#23699D" data-toggle="modal"  data-target=".bd-example-modal-lg" >Write Review</div>
</div>
    </section>

<section class="wht-new pb-5">
  <div class="container">
    <div class="col-lg-11 mx-auto wht-new-div">
      <h6 class="text-center">What’s new</h6>
      <div class="row ">
        <div class=" col-12 text-center">
          <img src="assets/images/whts-new.png" alt="" width="50%" class="img-fluid">
        </div>
        <div class=" col-12 mt-3" id="new">
          <h1 class="text-center">Hello! <br>Subscribe us for latest Offers</h1>
              <form method="post">
                <div class="row search">
                  <div class="input-group col-lg-6 py-1 col-10">
                      <input type="email" class="form-control mob-no" placeholder="Email" name="newsletter">
                  </div>
                  <div class="col-lg-2 col-2 pl-0" id="download">
                     <button class="btn search-btn" name="newsuser" style="padding:4px 10px;" type="submit">Get</button>
                  </div>

                </div>
              </form> 
        </div>
      </div>
    </div>
  </div>
</section>
<!-- rating model box -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content py-5">
      <h4 class="text-center" style="color:#23699D;font-size:1.2rem"> Please Give your Reviews And Rating.. </h4>
      <hr>
      <div class="container">  
    <form  method="post">
    <div class="form-group">
    <div class="rateyo" id= "rating"
         data-rateyo-rating="0"
         data-rateyo-num-stars="5"
         data-rateyo-score="3">
         </div>
     <span class='result'>0</span>
    <input type="hidden" name="rating" value="">
    </div>
    <div class="form-group my-1">
      <input type="text" name="rname" class="form-control" placeholder="Enter Your Name" style="color:#23699D;" required >
    </div>
    <div class="form-group my-1">
      <input type="text" name="rcity" class="form-control" placeholder="Enter Your City" style="color:#23699D;" required>
    </div>
    <div class="form-group my-1">
      <textarea class="form-control" name="msg" placeholder="please write your riview" style="color:#23699D;"  required ></textarea>
    </div>
    <div class="form-group text-center">
    <button type="submit" class="btn text-white" name="review" style="background-color:#23699D;">Submit</button>
    </div>
  </form>
  </div>

    </div>
  </div>
</div>
<!-- rating model box end -->
<div class="container-fluid p-2" id="constantfooter">
  <div class="row">
  <div class="col-4 text-center" ><a href="contact.php" class="text-white"><i class="fas fa-phone-square" style="font-size:30px;"></i></a></div>
  <div class="col-4 text-center" ><a href="index1.php" class="text-white"><i class="fas fa-home" style="font-size:30px;"></i></a></div>
  <div class="col-4 text-center" ><a href="userdashboard.php" class="text-white"><i class="far fa-user-circle" style="font-size:30px;"></i></a></div>
  </div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
<!-- rating script -->
<script>
  $(function () {
 $("#rating").rateYo({
  ratedFill: "#23699D"
 });

})
</script>
<script>
 $(function () {
     $(".rateyo").rateYo().on("rateyo.change", function (e, data) {
         var rating = data.rating;
         $(this).parent().find('.score').text('score :'+ $(this).attr('data-rateyo-score'));
         $(this).parent().find('.result').text('Rating :'+ rating);
         $(this).parent().find('input[name=rating]').val(rating); //add rating value to input field
 });
   
 });
</script>

<script>
  $('.owl-carousel-12').owlCarousel({
    loop:true,
    margin:12,
    // nav:true,
    responsive:{
        0:{
            items:3
        },
        600:{
            items:4
        },
        1000:{
            items:4
        }
    }
})
</script>
<!-- rating script end -->
<script>
  $('.owl-carousel').owlCarousel({
    // loop:true,
    margin:12,
    // nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
</script>


</body>
</html>

<script>
$(document).ready(function(){
 $("#modalsearch").keyup(function(){
   var search = $("#modalsearch").val();
   if(search != ''){
      $.ajax({
				  method: "post",
				  url : "modalfound.php",
				  data:{search:search},
				  dataType: "html",
				  success:function(result)
				  {
            $('#ajaxresponse').fadeIn();
            $("#filter").css("display", "block");
					  $('#ajaxresponse').html(result);
				  }
			});
    }else{
      $('#ajaxresponse').fadeOut();
      $("#filter").css("display", "none");
      $('#ajaxresponse').html("");
    }
 })
});
</script>

<script>
  $(document).ready(function(){
    $("#searchmobile").keyup(function(){
      var search = $("#searchmobile").val();
   if(search != ''){
      $.ajax({
				  method: "post",
				  url : "modalfound1.php",
				  data:{search:search},
				  dataType: "html",
				  success:function(result)
				  {
            $('.filter').fadeIn();
            $(".filter").css("display", "block");
					  $('.response').html(result);
				  }
			});
    }else{
      $('.filter').fadeOut();
      $(".filter").css("display", "none");
      $('.response').html("");
    }
 })
    });
</script>

<script>
 $(document).ready(function(){
   $("#userpic").on('click',function(){
     $("#prof").toggle();
   });
 });
</script>
