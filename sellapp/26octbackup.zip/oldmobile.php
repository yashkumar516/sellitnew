<?php include 'header.php' ?>

<?php
 $id = $_REQUEST['id'];
?>
<section class="sell-section">
  <h1 class="sell-header text-center">Sell Old Samsung Model</h1> 
</section>

<!-- galaxy  -->
<section class="galaxy">
    <div class="container px-0">
        <div class="col-lg-12 mx-auto">
        <h6 class="select mb-3">Select Series</h6>
            <div class="row">
            <?php
                    $selectseries = mysqli_query($con,"SELECT * FROM `childcategory` WHERE `status` = 'active' AND `subcatid` = '$id'");
                    while($arseries = mysqli_fetch_assoc( $selectseries ))
                    {
                   ?>
                <div class="col-lg-2 col-6"><button class="box2" onclick="return getmodel(<?php echo $arseries['id'] ?>)"> <b> <?php echo $arseries['childcategory'] ?> </b></button></div>
               <?php
                  }
              ?>
            </div>

        </div>
    </div>
</section>

<!-- select product -->
<section class="select-product">
    <div class="container px-0">
            <div class="col-lg-12 mx-auto">
            <h1 class="select pb-3">Select Model</h1>
                <div class="row" id="ajaxrespon">
                <?php
                    $selectmodel = mysqli_query($con,"SELECT * FROM `product` WHERE `status` = 'active' AND `subcategoryid` = '$id'");
                    while($armodel = mysqli_fetch_assoc( $selectmodel ))
                    {
                   ?>
                  <div class="col-lg-2 col-4 mt-4" >
                    <a href="variant.php?id=<?php echo $armodel['id'] ?>&&bid=<?php echo $id ?>">
                    <div class="text-center" id="md">
                         <img src="../admin/img/<?php echo $armodel['product_image'] ?>" width="100%" class="img-fluid" alt=""> 
                     <span class="sum-heading text-center mt-3"><?php echo $armodel['product_name'] ?></span> 
                    </div>
                    </a>
                    </div>
                     <?php
                    }
                    ?>
                </div>
            </div>
        
    </div>

</section>
<?php include 'footer.php' ?>

<script>
  function getmodel(gid){
   var sid = gid;
    if(sid != null){
     $.ajax({
                  method: "post",
                  url : "ajaxmodel.php",
                  data:{series:sid},
				  dataType: "html",
				  success:function(result)
				  {
                    $("#ajaxrespon").html(''); 
					$("#ajaxrespon").html(result); 
				  }
     });
    }
}
</script>