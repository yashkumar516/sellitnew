
 <?php include 'header.php' ?>
 <style>
 .row{
   margin-right:0px !important;
   margin-left:0px !important;
 }
 </style>
    <section class="slider">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner ">
    <?php
     $selectbanner = mysqli_query($con,"SELECT * FROM `homebanner` WHERE `status` = 'active'");
     $active = 0;
     while($arbanner = mysqli_fetch_assoc($selectbanner))
     {
       if($active == '0')
       {
    ?>
    <div class="carousel-item active">
      <img class="d-block w-100" src="../admin/img/<?php echo $arbanner['image'] ?>" alt="First slide">
    </div>
 <?php
     }
   else{
 ?>
    <div class="carousel-item ">
      <img class="d-block w-100" src="../admin/img/<?php echo $arbanner['image'] ?>" alt="First slide">
    </div>
    <?php
    }
    $active++;
     }
    ?>
   
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    </section>

    <section class="py-2" style="background-color: #f1f8f8;">
      <div class="container sell px-2">
   
        <div class="col-lg-12 col-12  mx-auto card">
          <div class="row" id="sell">
            <?php
            $selectcat = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `category` WHERE `status` = 'active'"));
            ?>
          <div class="col-lg-4 col-4 text-center">
          <a href="mobile.php?id=<?php echo $selectcat['id'] ?>"><img src="../admin/img/<?php echo $selectcat['category_image'] ?>" class="img-fluid" alt="">
              <h4 class="text-uppercase"><?php echo $selectcat['category_name'] ?></h4></a>
            </div>
            <div class="col-lg-4 col-4 text-center">
            <img src="assets/images/sell-tablet.png" class="img-fluid" alt="">
              <h4 class="text-uppercase">sell tablet</h4></a>
            </div>
            <div class="col-lg-4 col-4 text-center">
            <img src="assets/images/sell-watch.png" class="img-fluid" alt="">
            <h4 class="text-uppercase">sell watch</h4>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="watch-div" style="background-color:#f0f2f2">
    <?php 
     $selmob = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `banner` WHERE `status` = 'active' AND `category` = 'Sell Phone' "));
    ?>
      <div class="container py-4">
        <div class="col-12 text-center ">
        <h1 class="tablet-heading text-center"><?php echo $selmob['title'] ?></h1>
            <img src="../admin/img/<?php echo  $selmob['banner_image'] ?>" width="50%" class="img-fluid" alt="">
          </div>
          <div class="col-12 search-option">
                  <div class="input-group">
                      <input type="text" id="searchmobile" class="form-control" placeholder="Search your Mobile to sell" name="search">
                  </div>
                  <div class=" col-11 filter">
                   <ul class="response p-2" type="none">

                   </ul>
                  </div>        
                <div class="row">
                          <div class="col-lg-3 col-3">
                            <hr style="border: 1px solid #23699D"> 
                          </div>
                          <div class="col-lg-6 col-6 text-center" id="mor">
                            <h6>or choose a brand</h6>
                          </div>
                          <div class="col-lg-3 col-3">
                            <hr style="border: 1px solid #23699D"> 
                          </div>
                        </div>
                <div class="row ">
                <?php
                 $selectquery = mysqli_query($con,"SELECT * FROM `subcategory` WHERE `status` = 'active' ORDER BY `id` DESC LIMIT 4 ");
                 while($ar = mysqli_fetch_assoc( $selectquery ))
                 {
                ?>
                <div class="col-lg-3 col-3"><a href="oldmobile.php?id=<?php echo $ar['id'] ?>"><img src="../admin/img/<?php echo $ar['subcategory_image'] ?>" class="img-fluid" alt=""></a></div>
                <?php
                 }
                 ?>
                </div>
               <div class="text-center">
                <a href="mobile.php"> <button class="btn brand-btn sm-brand mt-4">More Brands <i class="fas fa-chevron-right" aria-hidden="true"></i></button></a>
               </div>
          </div>
      </div>
    </section>
    <section id="have">
      <div class="container py-4">
      <?php 
       $seltab = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `banner` WHERE `status` = 'active' AND `category` = 'Tablet' "));
      ?>
          <div class="col-12 text-center">
          <h1 class="tablet-heading mb-4"><?php echo $seltab['title'] ?></h1>
            <img src="../admin/img/<?php echo $seltab['banner_image'] ?>" width="50%" class="img-fluid" alt="">
          </div>
          <div class="col-12 search-option">
            
                  <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search your Tablet to sell" name="search">
                  </div> 
                  <div class="row">
                      <div class="col-lg-3 col-3 ">
                        <hr style="border: 1px solid #23699D"> 
                      </div>
                      <div class="col-lg-6 col-6 text-center" id="choose">
                        <h6>or choose a brand</h6>
                      </div>
                      <div class="col-lg-3 col-3 ">
                        <hr style="border: 1px solid #23699D"> 
                      </div>
                    </div>
                <div class="row">
                <?php
                 $selectquery = mysqli_query($con,"SELECT * FROM `subcategory` WHERE `status` = 'active' ORDER BY `id` DESC LIMIT 4 ");
                 while($ar = mysqli_fetch_assoc( $selectquery ))
                 {
                ?>
                <div class="col-lg-3 col-3"><a href="oldmobile.php?id=<?php echo $ar['id'] ?>"><img src="../admin/img/<?php echo $ar['subcategory_image'] ?>" class="img-fluid" alt=""></a></div>
                <?php
                 }
                 ?>
                </div>
                <div class="text-center">
              <button class="btn brand-btn sm-brand mt-4" style="background-color: #f1f8f8;">More Brands <i class="fas fa-chevron-right" aria-hidden="true"></i></button>
               </div>
           
           
          </div>
      </div>

    </section>
      
    <section class="watch-div">
      <div class="container py-4">
      <?php 
        $selwatch = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `banner` WHERE `status` = 'active' AND `category` = 'Watch' "));
      ?>
        <div class="col-12 text-center">
            <h1 class="tablet-heading mb-4"><?php echo $selwatch['title'] ?></h1>
            <img src="../admin/img/<?php echo $selwatch['banner_image'] ?>" width="50%"  class="img-fluid" alt="">
        </div>
        <div class="col-12 search-option">
                  <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search your Watch to sell" name="search">
                  </div>          
                <div class="row">
                          <div class="col-lg-3 col-3">
                            <hr style="border: 1px solid #23699D"> 
                          </div>
                          <div class="col-lg-6 col-6 text-center" id="mor">
                            <h6>or choose a brand</h6>
                          </div>
                          <div class="col-lg-3 col-3">
                            <hr style="border: 1px solid #23699D"> 
                          </div>
                        </div>
                        <div class="row">
                <?php
                 $selectquery = mysqli_query($con,"SELECT * FROM `subcategory` WHERE `status` = 'active' ORDER BY `id` DESC LIMIT 4 ");
                 while($ar = mysqli_fetch_assoc( $selectquery ))
                 {
                ?>
                <div class="col-lg-3 col-3"><a href="oldmobile.php?id=<?php echo $ar['id'] ?>"><img src="../admin/img/<?php echo $ar['subcategory_image'] ?>" class="img-fluid" alt=""></a></div>
                <?php
                 }
                 ?>
                </div>
                <div class="text-center">
                 <button class="btn brand-btn sm-brand mt-4">More Brands <i class="fas fa-chevron-right" aria-hidden="true"></i></button>
               </div>
           
          </div>
      </div>
    </section>
    
  <?php include 'footer.php' ?>