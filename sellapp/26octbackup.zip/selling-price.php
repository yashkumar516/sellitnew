<?php include 'header.php' ?>
 <?php 
 if(isset($_REQUEST['enid'])){
     $enqid = $_REQUEST['enid'];
     $selectenqid = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `enquiry` WHERE `id` = '$enqid' "));
 }
?>
<section class="sell-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mx-auto">
                <h1 class="sell-header">Sell Old Samsung Model</h1>
            </div>   
           
        </div>
    </div>
</section>

<section class="product-detail">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-4 ">
                <img src="../admin/img/<?php echo $selectenqid['mimg'] ?>" class="img-fluid"  alt=""> 
            </div>
            <div class="col-lg-7 col-8 variant mx-uto">
                <h1 class="sum-heading " style="font-size:1.5rem;"><?php echo $selectenqid['model_name']  ?></h1>
                <p class="ques">Selling Price</p>
                <h1 class="sum-heading text-left" style="font-size:1.5rem;">Rs. <?php echo $selectenqid['offerprice']  ?>/-</h1>
                <p class="ques">(The value is based on the condition of the product mentioned by you)</p>
                
            </div>
            </div>
    </div>
</section>

<?php include 'footer1.php' ?>