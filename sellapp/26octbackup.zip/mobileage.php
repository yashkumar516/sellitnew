<?php include 'header.php' ?>
<?php
include 'include/mobileage1.php';
$vid = $_REQUEST['vid'];
$bid = $_REQUEST['bid'];
$mid = $_REQUEST['mid'];
$selectmodel = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `product` WHERE `id` = '$mid' "));
?>
<section class="sell-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <h1 class="sell-header">Sell Old Samsung Model</h1>
            </div>   
           
        </div>
    </div>
</section>
<form action="functional.php?vid=<?php echo $vid ?>&&bid=<?php echo $bid ?>&&mid=<?php echo $mid ?>" method="post">
<section class="product-detail">
    <div class="container">
        <div class="row">
        <div class="col-lg-5 px-0" id="selllimg">
                <div class="row pt-2 px-2 ">
                    <div class="col-4 text-right"> <img src="admin/img/<?php echo $selectmodel['product_image'] ?>" class="img-fluid" width="50%"  alt=""></div>
                    <div class="col-6"> 
                      <h1 class="sum-heading pt-4 "><?php echo $selectmodel['product_name'] ?></h1>
                      <p class="qty ">215+ Device Sold with us</p>
                      </div>
                </div>
                <hr>
                <div class="device px-3" >
                <h1 class="sum-heading ">Device Evaluation</h1>
                 <p id="devicedetail"><?php echo  $devicedetail ?></p>
                 <p id="call"><?php echo $call ?></p>
                <p id="screen"><?php echo $screen ?></p>
                <p id="body"><?php echo $body ?></p>
                <p id="war"><?php echo $war ?></p>
                <!-- screen start -->
                <p id="screencondition"><?php echo $screencondition ?></p>
                <p id="touch"><?php echo $touch ?></p>
                <p id="spot"><?php echo $spot ?></p>
                <p id="lines"><?php echo $lines ?></p>
                <p id="physical"><?php echo $physical ?></p>
                <!-- bodystart -->
                <p id="overall"><?php echo $overallcondition ?></p>
                <p id="Scratches"><?php echo $Scratches ?></p>
                <p id="dents"><?php echo $dents ?></p>
                <p id="side"><?php echo $side ?></p>
                <p id="bent"><?php echo $bents?></p>
                 <!-- warrent strt -->
                 <p id="mobage"></p>
                 <p id="age"></p>
                </div>
            </div>
            <div class="col-12 mx-auto mobileage s">
                <p class="ques pl-4">What is your Mobile age?</p>
                <div class="container-fluid">
                <div class="row pt-3">
                      <div class="col-11 mobileage-coll mx-auto py-3 my-2">
                        <label for="toggle1" class="px-2">
                          <input id="toggle1" name="war" class="war" value="under3" type="radio" required>
                          <span>Below 3 Months</span>
                        </label>
                        
                      </div>
                      <div class="col-11 mobileage-coll mx-auto py-3 my-2">
                          <label for="toggle2" class="px-2">
                              <input id="toggle2" name="war" class="war" value="under6" type="radio" required>
                              <span> 3 to 6 Months</span>
                            </label>
                         
                      </div>
                      <div class="col-11 mobileage-coll mx-auto py-3 my-2">
                          <label for="toggle3" class="px-2">
                              <input id="toggle3" name="war" class="war" value="under11" type="radio" required>
                              <span>   6 to 11 Months</span>
                            </label>
                         
                      </div>
                      <div class="col-11 mobileage-coll mx-auto py-3 my-2">
                          <label for="toggle4" class="px-2">
                              <input id="toggle4" name="war" class="war" value="above11" type="radio" required>
                              <span>Above 11 Months</span>
                            </label>
                           
                  </div>
                </div>
                </div>
            
                <div class="text-center mt-4">
                <input type="hidden" id="callin" name="callin" value="<?php echo $call ?>">
                    <input type="hidden" id="screenin" name="screenin" value="<?php echo $screen ?>">
                    <input type="hidden" id="bodyin" name="bodyin" value="<?php echo $body ?>">
                    <input type="hidden" id="warin" name="warin" >  
                    <input type="hidden"  name="devicedetail" value="Device Details">
                    <input type="hidden" id="touchin" name="touch" value="<?php echo $touch ?>">
                    <input type="hidden" id="spotin" name="spot" value="<?php echo $spot ?>">
                    <input type="hidden" id="linesin" name="lines" value="<?php echo $lines ?>" >
                    <input type="hidden" id="physicalin" name="physical" value="<?php echo $physical ?>" >
                    <input type="hidden" id="screencondition" name="screencondition" value="<?php echo $screencondition ?>">
                    <input type="hidden" id="Scratchesin" name="Scratches" value="<?php echo $Scratches ?>">
                    <input type="hidden" id="dentsin" name="dents" value="<?php echo $dents ?>">
                    <input type="hidden" id="sidein" name="side" value="<?php echo $side ?>">
                    <input type="hidden" id="bentin" name="bent" value="<?php echo $bents ?>">
                    <input type="hidden" id="overallcondition" name="overallcondition" value="<?php echo $overallcondition ?>">
                    <!-- mobileage start -->
                    <input type="hidden" id="mobagein" name="mobage" value="Mobile Age">
                    <input type="hidden" id="agein" name="age" value="">
                    </div>
            </div>
            </div>
    </div>
</section>

<!-- footer start here -->
    <!-- Optional JavaScript -->
    <div class="container-fluid text-center p-2" id="constantfooter">
    <button class="btn contin-btn" name="questions">Continue  <i class="fas fa-arrow-right"></i></button>
    </div>
  </form>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<script>
$(document).ready(function(){
 $("#modalsearch").keyup(function(){
   var search = $("#modalsearch").val();
   if(search != ''){
      $.ajax({
				  method: "post",
				  url : "modalfound.php",
				  data:{search:search},
				  dataType: "html",
				  success:function(result)
				  {
            $('#ajaxresponse').fadeIn();
            $("#filter").css("display", "block");
					  $('#ajaxresponse').html(result);
				  }
			});
    }else{
      $('#ajaxresponse').fadeOut();
      $("#filter").css("display", "none");
      $('#ajaxresponse').html("");
    }
 })
});
</script>

<script>
 $(document).ready(function(){
   $("#userpic").on('click',function(){
     $("#prof").toggle();
   });
 });
</script>
<!-- footer end -->

<script>
$(document).ready(function() {
    $(".war").click(function() {
        
      var war = $("input[type=radio][name=war]:checked").val();
        if(war == "under3")
        {
            $('#mobage').html("Mobile Age");
            $('#age').html("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>Under 3 Months");
            $('#agein').val("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>Under 3 Months");
            $('#war').html('<?php echo $war ?>');
        }
        else if(war == "under6"){   
            $('#mobage').html("Mobile Age");
            $('#age').html("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>3 To 6 Months");
            $('#agein').val("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>3 To 6 Months");
            $('#war').html('<?php echo $war ?>');
        }
        else if(war == "under11"){   
            $('#mobage').html("Mobile Age");
            $('#age').html("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>6 To 11 Months");
            $('#agein').val("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>6 To 11 Months");
            $('#war').html('<?php echo $war ?>');
        }
        else if(war == "above11"){   
            $('#mobage').html("Mobile Age");
            $('#war').html("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>Mobile Out of Warranty");
            $('#age').html("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>Above 11 Months");
            $('#agein').val("<i class='fas fa-dot-circle' style='font-size:10px;margin-right:12px;color:#1B6C9E;' ></i>Above 11 Months");
        }
    });
   });

   </script>
     <script>
     $(document).ready(function(){     
       $('.war').click(function() {
         var warrenty = $('#war').html();
         $("#warin").val(warrenty);
       })
     });
   </script>