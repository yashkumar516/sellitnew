
<?php include 'header.php' ?>
<?php
if(isset($_REQUEST['vid']) && isset($_REQUEST['mid']) &&  isset($_REQUEST['bid']) && isset($_REQUEST['enid'])){
    $vid = $_REQUEST['vid'];
    $bid = $_REQUEST['bid'];
    $mid = $_REQUEST['mid'];
    $enqid = $_REQUEST['enid'];
    $seleenq = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `enquiry` WHERE `id` = ' $enqid' "));
}
?>
<section class="sell-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mx-auto">
                <h1 class="sell-header">Sell Old Samsung Model</h1>
            </div>
        </div>
    </div>
</section>

<section class="product-detail">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-5 col-5 ">
              <img src="../admin/img/<?php echo $seleenq['mimg'] ?>" class="img-fluid" width="80%" alt="">
            </div>
            <div class="col-lg-4 col-md-4 col-sm-7 col-7 variant">
              <h1 class="sum-heading text-left"><?php echo $seleenq['model_name'] ?></h1>
              <p class="ques text-left">Our Offer Price </p>
              <h1 class="sum-heading text-left">Rs. <?php echo $seleenq['offerprice'] ?>/-</h1>
              <p class="ques text-left">(The value is based on the condition of the product mentioned by you)</p>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-12 price-summary">
                <div class="card">
                    <h1>Price Summary</h1>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1">
                            <p class="charges">Base Price</p>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1 d-flex justify-content-end">
                            <p class="rate">₹<?php echo $seleenq['offerprice'] ?></p>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1">
                            <p class="charges">Pickup Charges</p>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1 d-flex justify-content-end">
                            <p class="rate">Free <strike> ₹100 </strike></p>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1">
                            <p class="charges">Total Amount</p>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 py-1 d-flex justify-content-end">
                            <p class="rate">₹<?php echo $seleenq['offerprice'] ?></p>
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <a href="uploadimage.php?enid=<?php echo  $enqid ?>&&uid=<?php echo $seleenq['userid'] ?>"><button class="btn contin-btn">Get Paid <i class="fas fa-arrow-right"></i></button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer1.php' ?>