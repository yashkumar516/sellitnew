<?php
  if(isset($_POST['query']))
  {
      $screen = $_POST['screenin'];
      $body = $_POST['bodyin'];
      $call = $_POST['callin'];
      $war = $_POST['warin'];
      $devicedetail = $_POST['devicedetail'];
  }

?>