<?php
  if(isset($_POST['questions']))
  {
      $screen = $_POST['screenin'];
      $body = $_POST['bodyin'];
      $call = $_POST['callin'];
      $war = $_POST['warin'];
      //   screen start
      $screencondition = $_POST['screencondition'];
      $touchwork = $_POST['touch'];
      $spot = $_POST['spot'];
      $lines = $_POST['lines'];
     $physical = $_POST['physical'];
      //   body start
      $devicedetail = $_POST['devicedetail'];
      $Scratches = $_POST['Scratches'];
      $dents = $_POST['dents'];
      $side = $_POST['side'];
      $bents = $_POST['bent'];
      $overallcondition = $_POST['overallcondition'];
      // mobile age
      $mobage = $_POST['mobage'];
      $age = $_POST['age'];
    //   functional start
      $functional = $_POST['functional'];
      $frontcamin = $_POST['frontcamin'];
      $backcamin = $_POST['backcamin'];
      $volumein = $_POST['volumein'];
      $fingertouchin = $_POST['fingertouchin'];
      $speakerin = $_POST['speakerin'];
      $powerin = $_POST['powerin'];
      $chargingin = $_POST['chargingin'];
      $facein = $_POST['facein'];
      $audioin = $_POST['audioin'];
      $camglassin = $_POST['camglassin'];
      $wifiin = $_POST['wifiin'];
      $silentin = $_POST['silentin'];
      $battryin = $_POST['battryin'];
      $bluetoothin = $_POST['bluetoothin'];
      $vibratein = $_POST['vibratein'];
      $microin = $_POST['microin'];

  }
?>