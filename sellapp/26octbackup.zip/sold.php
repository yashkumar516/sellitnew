<?php include 'header.php' ?>

<?php
 $vid = $_REQUEST['vid'];
 $mid = $_REQUEST['mid'];
 $bid = $_REQUEST['bid'];
 $selectmodel = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `product` WHERE `id` = '$mid' "));
 $selectvarient = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `varient` WHERE `varient` = '$vid' AND `product_name`='$mid' "));
?>
<div class="container-fluid" id="sold">
<div class="row" >
    <div class="col-12 col-lg-7 mx-auto py-5" id="soldpage">
      <h3 >Sell Old Samsung Model</h3>
    </div>
</div>
<div class="row pb-5">
            <div class="col-12 text-center">
                <img src="../admin/img/<?php echo $selectmodel['product_image'] ?>" class="img-fluid"  width="60%" alt="">
            </div>
            <div class="col-12 text-center">
                <h1><?php echo $selectmodel['product_name'] ?></h1>
                <!-- <p>215+ Devices sold with us</p> -->
                <h1>Get Upto</h1>
                <h1>Rs. <?php echo $selectvarient['uptovalue'] ?>/-</h1>
            </div>         
   </div>
   </div>

<!-- footer start here -->
    <!-- Optional JavaScript -->
  <div class="container-fluid text-center p-2" id="constantfooter">
  <a class="contin-btn text-white btn" href="product-query.php?upto=<?php echo $selectvarient['id'] ?>&&mid=<?php echo $mid ?>&&bid=<?php echo $bid ?>">
  Get Exact Value  <i class="fas fa-arrow-right" aria-hidden="true"></i>
  </a> 
</div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<script>
$(document).ready(function(){
 $("#modalsearch").keyup(function(){
   var search = $("#modalsearch").val();
   if(search != ''){
      $.ajax({
				  method: "post",
				  url : "modalfound.php",
				  data:{search:search},
				  dataType: "html",
				  success:function(result)
				  {
            $('#ajaxresponse').fadeIn();
            $("#filter").css("display", "block");
					  $('#ajaxresponse').html(result);
				  }
			});
    }else{
      $('#ajaxresponse').fadeOut();
      $("#filter").css("display", "none");
      $('#ajaxresponse').html("");
    }
 })
});
</script>

<script>
 $(document).ready(function(){
   $("#userpic").on('click',function(){
     $("#prof").toggle();
   });
 });
</script>

